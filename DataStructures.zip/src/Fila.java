
public interface Fila {
	
	public void enqueue(Object value);
	public Object dequeue();
	
	public boolean isFull();
	public boolean isEmpty();
	public void Print();
	
}
