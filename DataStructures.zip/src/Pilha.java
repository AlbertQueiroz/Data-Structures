
public interface Pilha {
	
	public void push(Object value);
	public Object pop();
	
	public boolean isFull();
	public boolean isEmpty();
	
}
